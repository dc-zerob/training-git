package it.zerob.sample;

public class Sample {

	public static void main (String [] args){
		System.out.println("Sample project");
	}
}
